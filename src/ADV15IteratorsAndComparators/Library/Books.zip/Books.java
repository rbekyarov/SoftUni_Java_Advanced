package ADV15IteratorsAndComparators.Library;

public class Books {
    private String title;

    public Books(String title) {
        this.title = title;
    }


    public String getTitle() {
        return this.title;
    }
}
